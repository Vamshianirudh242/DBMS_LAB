"""Compare acquisition channels on equal first-30-day windows with bootstrap CIs."""
from pathlib import Path
import numpy as np, pandas as pd
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/"Data"; OUT=ROOT/"Analysis"
rng=np.random.default_rng(42)
p=pd.read_csv(DATA/"player_profile.csv",usecols=["device_id","install_date","acquisition_channel"]); p["install_date"]=pd.to_datetime(p.install_date)
# Jan-Mar installs have a complete 30-day observation window within the supplied telemetry period.
p=p[p.install_date.between("2026-01-01","2026-03-31")].copy()
d=pd.read_csv(DATA/"player_day.csv"); d["date"]=pd.to_datetime(d.activity_date.astype(str),format="%Y%m%d")
x=d.merge(p[["device_id","install_date"]],on="device_id"); x=x[(x.date>=x.install_date)&(x.date<x.install_date+pd.Timedelta(days=30))]
eng=x.groupby("device_id").agg(active_days_30d=("date","nunique"),sessions_30d=("session_count","sum"),playtime_minutes_30d=("playtime_minutes","sum"))
buy=pd.read_csv(DATA/"purchase.csv"); buy["date"]=pd.to_datetime(buy.event_ts).dt.normalize(); y=buy.merge(p[["device_id","install_date"]],on="device_id"); y=y[(y.date>=y.install_date)&(y.date<y.install_date+pd.Timedelta(days=30))]; rev=y.groupby("device_id").usd_amount.sum().rename("revenue_30d_usd")
players=p.set_index("device_id").join(eng).join(rev).fillna(0).reset_index(); metrics=["active_days_30d","sessions_30d","playtime_minutes_30d","revenue_30d_usd"]
summary=players.groupby("acquisition_channel")[metrics].agg(["count","mean","median"]).round(4); summary.to_csv(OUT/"acquisition_channel_summary.csv")
# Percentile bootstrap CI for difference in mean 30-day revenue/install: organic minus each paid channel.
for channel in ["paid_social","paid_video"]:
    a=players.loc[players.acquisition_channel=="organic","revenue_30d_usd"].to_numpy(); b=players.loc[players.acquisition_channel==channel,"revenue_30d_usd"].to_numpy()
    if len(a)==0 or len(b)==0: continue
    diffs=np.empty(2000)
    for i in range(len(diffs)): diffs[i]=rng.choice(a,len(a),replace=True).mean()-rng.choice(b,len(b),replace=True).mean()
    print(f"organic - {channel}: mean difference=${a.mean()-b.mean():.4f}; 95% bootstrap CI=({np.quantile(diffs,.025):.4f}, {np.quantile(diffs,.975):.4f})")
print("\nChannel summary (CSV saved):\n",summary.to_string()); print("\nSaved Analysis/acquisition_channel_summary.csv")

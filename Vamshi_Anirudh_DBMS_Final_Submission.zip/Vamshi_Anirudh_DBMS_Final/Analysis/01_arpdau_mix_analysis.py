"""Reproduce the first-30 vs last-30 day ARPDAU comparison by country tier."""
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/"Data"; OUT=ROOT/"Analysis"
profile=pd.read_csv(DATA/"player_profile.csv",usecols=["device_id","country_tier"])
days=pd.read_csv(DATA/"player_day.csv"); days["date"]=pd.to_datetime(days.activity_date.astype(str),format="%Y%m%d")
purchases=pd.read_csv(DATA/"purchase.csv"); purchases["date"]=pd.to_datetime(purchases.event_ts).dt.normalize()
periods={"first_30":("2026-01-01","2026-01-30"),"last_30":("2026-04-01","2026-04-30")}
d=days.merge(profile,on="device_id",how="left")
rows=[]
for period,(start,end) in periods.items():
    x=d[d.date.between(start,end)]
    dau_days=x.groupby("country_tier").size().rename("dau_days")
    rev=purchases[purchases.date.between(start,end)].merge(profile,on="device_id").groupby("country_tier").usd_amount.sum().rename("revenue_usd")
    z=pd.concat([dau_days,rev],axis=1).fillna(0).reset_index(); z["period"]=period; z["arpdau"]=z.revenue_usd/z.dau_days
    rows.append(z)
result=pd.concat(rows,ignore_index=True); result.to_csv(OUT/"arpdau_tier_comparison.csv",index=False)
wide=result.pivot(index="country_tier",columns="period",values="arpdau"); wide["change_pct"]=(wide.last_30/wide.first_30-1)*100
print(wide.round(4).to_string()); print("\nSaved Analysis/arpdau_tier_comparison.csv")

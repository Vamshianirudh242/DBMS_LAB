
"""
DBMS Lab End-Sem analysis
Vamshi Anirudh | 24MAB0A42
Place the five CSV files in ./data/ and run: python churn_analysis.py
Dependencies: pandas, numpy, scikit-learn, matplotlib
"""
import os, glob
import pandas as pd, numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, precision_score, recall_score, f1_score, confusion_matrix

DATA_DIR=str(__import__("pathlib").Path(__file__).resolve().parents[1] / "Data")
def load(name):
    paths=glob.glob(os.path.join(DATA_DIR,name+"*.csv"))
    if not paths: raise FileNotFoundError(f"Missing {name}.csv in {DATA_DIR}")
    return pd.read_csv(paths[0])
profile=load("player_profile")
days=load("player_day")
profile["install_date"]=pd.to_datetime(profile.install_date)
days["date"]=pd.to_datetime(days.activity_date.astype(str),format="%Y%m%d")
snapshots=pd.to_datetime(["2026-02-01","2026-02-15","2026-03-01","2026-03-15","2026-03-31"])
frames=[]
for cutoff in snapshots:
    hist=days[(days.date>=cutoff-pd.Timedelta(days=13))&(days.date<=cutoff)]
    future=days[(days.date>cutoff)&(days.date<=cutoff+pd.Timedelta(days=14))]
    x=hist.groupby("device_id").agg(active_days=("date","nunique"),sessions14=("session_count","sum"),minutes14=("playtime_minutes","sum"),avg_level=("player_level","mean")).reset_index()
    last=hist.groupby("device_id").date.max().rename("last_active").reset_index()
    x=x.merge(last,on="device_id")
    x["recency_days"]=(cutoff-x.last_active).dt.days
    x["churn14"]=(~x.device_id.isin(set(future.device_id))).astype(int)
    x["cutoff"]=cutoff
    x=x.merge(profile[["device_id","install_date","country_tier"]],on="device_id",how="left")
    x["tenure_days"]=(cutoff-x.install_date).dt.days
    frames.append(x)
all_rows=pd.concat(frames,ignore_index=True)
features=["active_days","sessions14","minutes14","avg_level","recency_days","tenure_days","country_tier"]
train=all_rows[all_rows.cutoff<snapshots[-1]]
test=all_rows[all_rows.cutoff==snapshots[-1]]
model=make_pipeline(StandardScaler(),LogisticRegression(max_iter=1200,class_weight="balanced",random_state=42))
model.fit(train[features].fillna(0),train.churn14)
score=model.predict_proba(test[features].fillna(0))[:,1]
pred=(score>=0.5).astype(int)
print("Test rows:",len(test),"Churn rate:",round(test.churn14.mean(),4))
print("ROC AUC:",round(roc_auc_score(test.churn14,score),4))
print("Average precision:",round(average_precision_score(test.churn14,score),4))
print("Precision / recall / F1 at 0.50:",round(precision_score(test.churn14,pred),4),round(recall_score(test.churn14,pred),4),round(f1_score(test.churn14,pred),4))
print("Confusion matrix:\n",confusion_matrix(test.churn14,pred))

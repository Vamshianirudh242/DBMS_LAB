# DBMS Lab End-Sem Submission
**Vamshi Anirudh | Roll No. 24MAB0A42**

## Folder structure
- `Vamshi_Anirudh_DBMS_EndSem.pptx` — 7-slide Product Director readout followed by appendix slides. The assignment's 8-slide limit applies to the readout; appendix follows it.
- `SQL/` — seven focused SQLite query files covering daily health, retention, spender behaviour, rewarded ads, ARPDAU mix shift, acquisition channels, and the churn snapshot population.
- `Analysis/` — three Python analyses: ARPDAU by tier, acquisition-channel comparison with bootstrap confidence intervals, and churn prediction.
- `Data/` — the five original CSV datasets supplied for the exercise.

## Run the Python analyses
Use Python 3. Install dependencies:
```bash
pip install pandas numpy scikit-learn
```
Run from the submission root:
```bash
python Analysis/01_arpdau_mix_analysis.py
python Analysis/02_acquisition_channel_analysis.py
python Analysis/03_churn_prediction.py
```
The first two scripts save their summary CSVs in `Analysis/`. The churn script prints test-set metrics.

## Run the SQL
Import each file in `Data/` into SQLite as a table with the same base name (`player_profile`, `player_day`, `purchase`, `ad_view`, `currency_spend`). Then execute the relevant `.sql` file in `SQL/`. The queries use SQLite syntax and the supplied event dates.

## Scope and interpretation
- Revenue means in-app purchase USD only. Rewarded-ad rows measure engagement; `reward_amount` is in-game currency, not revenue.
- No marketing spend, ad-network payout, or offer-cost data were supplied, so ROAS, ad revenue, and offer ROI cannot be calculated.
- Acquisition comparisons are observational, not causal.
- Churn is defined in the model script as no active day in the 14 days after a scoring date, among players active in the preceding 14 days.
- Deliverable 4b (90-day new-install value prediction) is optional and intentionally omitted in favour of the requested churn analysis.

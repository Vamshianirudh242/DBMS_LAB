-- DBMS LAB END SEM | Vamshi Anirudh | 24MAB0A42
-- SQLite query; import CSVs as tables named after their filenames (without .csv).

-- 1(d1) Share of ad-watching player-days that reached their cap
WITH player_day_ads AS (
 SELECT device_id, date(event_ts) AS ad_date,
        MAX(ad_daily_count) AS max_count, MAX(ad_daily_cap) AS cap,
        SUM(CASE WHEN status='started' THEN 1 ELSE 0 END) AS started
 FROM ad_view GROUP BY device_id,date(event_ts)
)
SELECT cap, COUNT(*) AS watching_player_days,
       SUM(CASE WHEN max_count>=cap THEN 1 ELSE 0 END) AS hit_cap_days,
       AVG(CASE WHEN max_count>=cap THEN 1.0 ELSE 0.0 END) AS share_hit_cap
FROM player_day_ads WHERE started>0 GROUP BY cap;

-- 1(d2) Daily ad interaction rows; also inspect statuses separately.
SELECT date(event_ts) AS ad_date, COUNT(*) AS interaction_rows,
       SUM(CASE WHEN status='started' THEN 1 ELSE 0 END) AS started,
       SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS completed,
       SUM(CASE WHEN status='abandoned' THEN 1 ELSE 0 END) AS abandoned
FROM ad_view GROUP BY date(event_ts) ORDER BY ad_date;

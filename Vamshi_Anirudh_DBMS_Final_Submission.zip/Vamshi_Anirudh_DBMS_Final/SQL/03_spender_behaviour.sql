-- DBMS LAB END SEM | Vamshi Anirudh | 24MAB0A42
-- SQLite query; import CSVs as tables named after their filenames (without .csv).

-- 1(c1) Cumulative revenue concentration among PAYERS only
WITH payer_revenue AS (
 SELECT device_id, SUM(usd_amount) AS revenue
 FROM purchase GROUP BY device_id
), ranked AS (
 SELECT *, ROW_NUMBER() OVER(ORDER BY revenue DESC, device_id) AS rn,
        COUNT(*) OVER() AS payer_count,
        SUM(revenue) OVER() AS total_revenue
 FROM payer_revenue
)
SELECT
  SUM(CASE WHEN rn <= CEIL(payer_count*0.01) THEN revenue ELSE 0 END)*1.0/MAX(total_revenue) AS top_1pct_share,
  SUM(CASE WHEN rn <= CEIL(payer_count*0.10) THEN revenue ELSE 0 END)*1.0/MAX(total_revenue) AS top_10pct_share,
  SUM(CASE WHEN rn <= CEIL(payer_count*0.50) THEN revenue ELSE 0 END)*1.0/MAX(total_revenue) AS top_50pct_share
FROM ranked;

-- 1(c2) First purchase delay and never-payer share
WITH first_buy AS (
 SELECT device_id, MIN(date(event_ts)) AS first_buy_date
 FROM purchase GROUP BY device_id
)
SELECT p.device_id,
       julianday(f.first_buy_date)-julianday(p.install_date) AS days_to_first_purchase
FROM player_profile p LEFT JOIN first_buy f USING(device_id);
-- Never payers = profiles without a matching row in first_buy.

-- 1(c3) Gap between consecutive purchases
WITH ordered AS (
 SELECT device_id, event_ts,
        LAG(event_ts) OVER(PARTITION BY device_id ORDER BY event_ts) AS previous_purchase
 FROM purchase
)
SELECT device_id, event_ts, previous_purchase,
       (julianday(event_ts)-julianday(previous_purchase)) AS gap_days
FROM ordered WHERE previous_purchase IS NOT NULL;

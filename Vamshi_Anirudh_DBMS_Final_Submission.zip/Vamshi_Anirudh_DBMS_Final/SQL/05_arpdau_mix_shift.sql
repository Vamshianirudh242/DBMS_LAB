-- DBMS LAB END SEM | Vamshi Anirudh | 24MAB0A42
-- SQLite query; import CSVs as tables named after their filenames (without .csv).

-- 2(a) ARPDAU by country tier: compare Jan 1-30 with Apr 1-30.
WITH dau AS (
 SELECT CASE WHEN (substr(CAST(activity_date AS TEXT),1,4)||'-'||substr(CAST(activity_date AS TEXT),5,2)||'-'||substr(CAST(activity_date AS TEXT),7,2)) BETWEEN '2026-01-01' AND '2026-01-30' THEN 'first_30'
             WHEN (substr(CAST(activity_date AS TEXT),1,4)||'-'||substr(CAST(activity_date AS TEXT),5,2)||'-'||substr(CAST(activity_date AS TEXT),7,2)) BETWEEN '2026-04-01' AND '2026-04-30' THEN 'last_30' END AS period,
        p.country_tier, COUNT(*) AS dau_days
 FROM player_day d JOIN player_profile p USING(device_id)
 WHERE (substr(CAST(activity_date AS TEXT),1,4)||'-'||substr(CAST(activity_date AS TEXT),5,2)||'-'||substr(CAST(activity_date AS TEXT),7,2)) BETWEEN '2026-01-01' AND '2026-01-30'
    OR (substr(CAST(activity_date AS TEXT),1,4)||'-'||substr(CAST(activity_date AS TEXT),5,2)||'-'||substr(CAST(activity_date AS TEXT),7,2)) BETWEEN '2026-04-01' AND '2026-04-30'
 GROUP BY 1,2
), revenue AS (
 SELECT CASE WHEN date(event_ts) BETWEEN '2026-01-01' AND '2026-01-30' THEN 'first_30'
             WHEN date(event_ts) BETWEEN '2026-04-01' AND '2026-04-30' THEN 'last_30' END AS period,
        p.country_tier, SUM(x.usd_amount) AS revenue
 FROM purchase x JOIN player_profile p USING(device_id)
 WHERE date(event_ts) BETWEEN '2026-01-01' AND '2026-01-30'
    OR date(event_ts) BETWEEN '2026-04-01' AND '2026-04-30'
 GROUP BY 1,2
)
SELECT d.period,d.country_tier,d.dau_days,COALESCE(r.revenue,0) AS revenue,
       COALESCE(r.revenue,0)*1.0/d.dau_days AS arpdau
FROM dau d LEFT JOIN revenue r USING(period,country_tier);

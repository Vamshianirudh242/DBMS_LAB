-- DBMS LAB END SEM | Vamshi Anirudh | 24MAB0A42
-- SQLite query; import CSVs as tables named after their filenames (without .csv).

-- 3) Acquisition: fixed first 30-day window, Jan-Mar installs only
WITH eligible AS (
 SELECT device_id, install_date, acquisition_channel
 FROM player_profile
 WHERE date(install_date) BETWEEN '2026-01-01' AND '2026-03-31'
), engagement AS (
 SELECT e.device_id, COUNT(DISTINCT d.activity_date) AS active_days,
        SUM(d.session_count) AS sessions_30d, SUM(d.playtime_minutes) AS playtime_30d
 FROM eligible e LEFT JOIN player_day d ON d.device_id=e.device_id
   AND date(d.activity_date)>=date(e.install_date)
   AND date(d.activity_date)<=date(e.install_date,'+29 day')
 GROUP BY e.device_id
), revenue AS (
 SELECT e.device_id, SUM(p.usd_amount) AS revenue_30d
 FROM eligible e LEFT JOIN purchase p ON p.device_id=e.device_id
   AND date(p.event_ts)>=date(e.install_date)
   AND date(p.event_ts)<=date(e.install_date,'+29 day')
 GROUP BY e.device_id
)
SELECT e.acquisition_channel, COUNT(*) AS installs,
       AVG(g.active_days) AS avg_active_days_30d,
       AVG(g.sessions_30d) AS avg_sessions_30d,
       AVG(g.playtime_30d) AS avg_playtime_30d,
       AVG(COALESCE(r.revenue_30d,0)) AS revenue_per_install_30d
FROM eligible e JOIN engagement g USING(device_id)
LEFT JOIN revenue r USING(device_id)
GROUP BY e.acquisition_channel;

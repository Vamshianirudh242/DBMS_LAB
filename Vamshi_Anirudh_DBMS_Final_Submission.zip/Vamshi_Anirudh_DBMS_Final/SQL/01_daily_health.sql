-- DBMS LAB END SEM | Vamshi Anirudh | 24MAB0A42
-- SQLite query; import CSVs as tables named after their filenames (without .csv).

-- 1(a) Daily health by day and platform
WITH daily_dau AS (
  SELECT d.activity_date, p.platform, COUNT(DISTINCT d.device_id) AS dau
  FROM player_day d JOIN player_profile p USING(device_id)
  GROUP BY d.activity_date, p.platform
), daily_purchase AS (
  SELECT CAST(strftime('%Y%m%d', datetime(event_ts)) AS INTEGER) AS activity_date,
         p.platform, SUM(x.usd_amount) AS gross_revenue,
         COUNT(DISTINCT x.device_id) AS purchasers
  FROM purchase x JOIN player_profile p USING(device_id)
  GROUP BY 1,2
)
SELECT a.activity_date, a.platform, a.dau,
       COALESCE(b.gross_revenue,0) AS gross_revenue,
       COALESCE(b.gross_revenue,0)*1.0/a.dau AS arpdau,
       COALESCE(b.purchasers,0)*1.0/a.dau AS purchaser_share
FROM daily_dau a LEFT JOIN daily_purchase b
  ON a.activity_date=b.activity_date AND a.platform=b.platform
ORDER BY 1,2;

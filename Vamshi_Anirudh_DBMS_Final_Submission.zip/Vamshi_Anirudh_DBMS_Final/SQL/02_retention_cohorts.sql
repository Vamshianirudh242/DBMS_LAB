-- DBMS LAB END SEM | Vamshi Anirudh | 24MAB0A42
-- SQLite query; import CSVs as tables named after their filenames (without .csv).

-- 1(b) Exact-age retention by install week. Recent cohorts have NULL where
-- the full milestone has not elapsed by the end of observation (2026-04-30).
WITH cohort AS (
 SELECT device_id, date(install_date) AS install_date,
        date(install_date,'weekday 0','-6 days') AS install_week
 FROM player_profile
 WHERE date(install_date) BETWEEN '2026-01-01' AND '2026-04-30'
), milestones AS (
 SELECT c.install_week, c.install_date, c.device_id,
        MAX(CASE WHEN julianday(substr(CAST(d.activity_date AS TEXT),1,4)||'-'||substr(CAST(d.activity_date AS TEXT),5,2)||'-'||substr(CAST(d.activity_date AS TEXT),7,2)) - julianday(c.install_date)=1 THEN 1 ELSE 0 END) AS d1,
        MAX(CASE WHEN julianday(substr(CAST(d.activity_date AS TEXT),1,4)||'-'||substr(CAST(d.activity_date AS TEXT),5,2)||'-'||substr(CAST(d.activity_date AS TEXT),7,2)) - julianday(c.install_date)=7 THEN 1 ELSE 0 END) AS d7,
        MAX(CASE WHEN julianday(substr(CAST(d.activity_date AS TEXT),1,4)||'-'||substr(CAST(d.activity_date AS TEXT),5,2)||'-'||substr(CAST(d.activity_date AS TEXT),7,2)) - julianday(c.install_date)=14 THEN 1 ELSE 0 END) AS d14,
        MAX(CASE WHEN julianday(substr(CAST(d.activity_date AS TEXT),1,4)||'-'||substr(CAST(d.activity_date AS TEXT),5,2)||'-'||substr(CAST(d.activity_date AS TEXT),7,2)) - julianday(c.install_date)=30 THEN 1 ELSE 0 END) AS d30
 FROM cohort c LEFT JOIN player_day d USING(device_id)
 GROUP BY c.install_week,c.install_date,c.device_id
)
SELECT install_week,
       COUNT(*) AS cohort_size,
       AVG(CASE WHEN date(install_date,'+1 day') <= '2026-04-30' THEN d1 END) AS day1_retention,
       AVG(CASE WHEN date(install_date,'+7 day') <= '2026-04-30' THEN d7 END) AS day7_retention,
       AVG(CASE WHEN date(install_date,'+14 day') <= '2026-04-30' THEN d14 END) AS day14_retention,
       AVG(CASE WHEN date(install_date,'+30 day') <= '2026-04-30' THEN d30 END) AS day30_retention
FROM milestones GROUP BY install_week ORDER BY install_week;

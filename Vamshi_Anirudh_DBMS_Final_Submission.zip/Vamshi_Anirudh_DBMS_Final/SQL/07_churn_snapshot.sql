-- DBMS LAB END SEM | Vamshi Anirudh | 24MAB0A42
-- SQLite query; import CSVs as tables named after their filenames (without .csv).

-- 4) Churn: model is implemented in churn_analysis.py. This query shows
-- the as-of snapshot population (active at least once in prior 14 days).
SELECT device_id, COUNT(DISTINCT activity_date) AS active_days_14d,
       SUM(session_count) AS sessions_14d,
       SUM(playtime_minutes) AS minutes_14d,
       MAX(activity_date) AS last_active_date
FROM player_day
WHERE activity_date BETWEEN 20260318 AND 20260331
GROUP BY device_id;
